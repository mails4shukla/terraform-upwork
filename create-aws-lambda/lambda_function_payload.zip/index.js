const http = require('http');
exports.handler = async (event) => {
    let dataString = '';
    var url=process.env.kubeurl;
    console.log(url);
    const response = await new Promise((resolve, reject) => {
        const req = http.get(url, function(res) {
          res.on('data', chunk => {
            dataString += chunk;
          });
          res.on('end', () => {
            resolve({
                statusCode: 200,
                body: dataString
            });
          });
        });
        
        req.on('error', (e) => {
          reject({
              statusCode: 500,
              body: 'Something went wrong!'
          });
        });
    });
    
    return response;
};